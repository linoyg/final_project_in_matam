//
// Created by linoy ganti on 8/7/2020.
//

#ifndef PROJECT_IN_MATAM_COMMANDS_H
#define PROJECT_IN_MATAM_COMMANDS_H

#include "Tokenize.h"

void handleAssignCommand(set<Graph> &set_of_graphs, const vector<string> &vec);


#endif //PROJECT_IN_MATAM_COMMANDS_H
